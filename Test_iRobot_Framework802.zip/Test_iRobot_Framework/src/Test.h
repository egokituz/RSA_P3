//
// File:   welcome.h
//

#ifndef _welcome_H
#define	_welcome_H



#endif	/* _welcome_H */
